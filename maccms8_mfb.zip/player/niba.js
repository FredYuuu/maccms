﻿MacPlayer.Html = '<iframe border="0" src="'+SitePath+'player/niba.html" width="100%" height="'+MacPlayer.Height+'" marginWidth="0" frameSpacing="0" marginHeight="0" frameBorder="0" scrolling="no" vspale="0" noResize></iframe>';
MacPlayer.Show();
